
#ifndef BTN_H_
#define BTN_H_

void BUTTON_init(void);

void EINT0_IRQHandler(void);
void EINT1_IRQHandler(void);
void EINT2_IRQHandler(void);

#endif
